// src/pages/MyOrders.jsx
import React, { useEffect, useState } from "react";
import { useAuth } from "../context/AuthContext";
import { db } from "../firebase";
import { collection, query, where, onSnapshot, orderBy } from "firebase/firestore";
import { useParams } from "react-router-dom";

const MyOrders = () => {
  const { user } = useAuth();
  const { storeSlug } = useParams(); // get current store slug from URL
  const [orders, setOrders] = useState([]);

  useEffect(() => {
    if (!user || !storeSlug) return;

    const q = query(
      collection(db, "orders"),
      where("customerId", "==", user.uid),
      where("storeSlug", "==", storeSlug), // 🔥 filter orders for this store only
      orderBy("createdAt", "desc")
    );

    const unsub = onSnapshot(q, (snap) => {
      setOrders(snap.docs.map((doc) => ({ id: doc.id, ...doc.data() })));
    });

    return () => unsub();
  }, [user, storeSlug]);

  if (!user) return <p className="p-4 text-center">Please login to view your orders.</p>;

  return (
    <div className="max-w-3xl mx-auto p-6">
      <h2 className="text-xl font-bold mb-4">My Orders</h2>
      {orders.length === 0 ? (
        <p>No orders found.</p>
      ) : (
        <div className="space-y-4">
          {orders.map((o) => (
            <div key={o.id} className="border p-4 rounded-lg shadow-sm">
              <p className="font-semibold">Order ID: {o.id}</p>
              <p>Status: <span className="font-medium">{o.status}</span></p>
              <p>Total: Rs {o.total}</p>
              <p>
                Date:{" "}
                {o.createdAt?.toDate
                  ? o.createdAt.toDate().toLocaleString()
                  : new Date(o.createdAt).toLocaleString()}
              </p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default MyOrders;
