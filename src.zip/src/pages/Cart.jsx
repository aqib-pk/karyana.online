export default function Cart() {
  return (
    <div className="p-4">
      <h2 className="text-2xl font-bold">Your Cart</h2>
      <p>Cart functionality coming soon...</p>
    </div>
  );
}
